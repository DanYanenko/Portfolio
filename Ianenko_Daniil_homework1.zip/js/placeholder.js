
jQuery(document).ready(function($) {

	
	$('input, textarea').placeholder({ customClass: 'my-placeholder' });
	
});

